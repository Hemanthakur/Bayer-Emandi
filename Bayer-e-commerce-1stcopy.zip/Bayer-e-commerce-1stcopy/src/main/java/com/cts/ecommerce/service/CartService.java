package com.cts.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ecommerce.model.Buyer;
import com.cts.ecommerce.model.Cart;
import com.cts.ecommerce.model.Product;
import com.cts.ecommerce.repository.CartRepository;
import com.cts.ecommerce.repository.ProductRepository;

@Service
public class CartService {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	
	public List<Cart> listCart(Buyer buyer){
		return cartRepository.findByBuyer(buyer);
	
}
	
	public Integer addProduct(Long productId, Integer quantity, Buyer buyer ,Product product) {
		Integer addedQuantity=quantity;
		
		Product product1=productRepository.findById(productId).get();
		Cart cart = cartRepository.findByBuyerAndProduct(buyer,product1);
		
		if(cart != null) {
			addedQuantity = cart.getQuantity()+ quantity;
			cart.setQuantity(addedQuantity);
		}else {
			cart = new Cart();
			cart.setQuantity(quantity);
			cart.setBuyer(buyer);
			cart.setProduct(product1);
		}
		
		cartRepository.save(cart);
		return addedQuantity;
	}
}