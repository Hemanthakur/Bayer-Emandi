package com.cts.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.ecommerce.model.Buyer;
import com.cts.ecommerce.model.Cart;
import com.cts.ecommerce.model.Product;
@Repository
public interface CartRepository extends JpaRepository<Cart,Integer> {

	public List<Cart> findByBuyer(Buyer buyer);
	
	public Cart findByBuyerAndProduct(Buyer buyer,Product product);
}
