package com.cts.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.ecommerce.model.Buyer;
import com.cts.ecommerce.model.Cart;
import com.cts.ecommerce.model.Product;
import com.cts.ecommerce.service.BuyerService;
import com.cts.ecommerce.service.CartService;

@Controller
public class CartController {
	@Autowired
	private CartService cartService;
	@Autowired
	private BuyerService buyerService;
	
	@GetMapping("/cart")
	public String showCart(Model model) {
//			@AuthenticationPrincipal Authentication authentication) {
		
		
		
		List<Cart> cart = cartService.listCart(null);
		
		model.addAttribute("cart", cart);
		return "shopping_cart";
	}
	
	@PostMapping("/cart/add/{pid}/{qty}")
	public Integer addProductToCart(@PathVariable("pid") Long productId,
			@PathVariable("qty") Integer quantity, Buyer buyer,Product product
			) {
		//System.out.println("addProductToCart: "+productId +" ."+quantity);
		
		
		Integer addedQuantity = cartService.addProduct(productId,quantity, buyer, product);
		
		System.out.println("item added");
		
		
		return addedQuantity ;
		
	}
	

}
